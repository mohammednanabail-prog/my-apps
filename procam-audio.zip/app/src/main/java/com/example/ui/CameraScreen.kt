package com.example.ui

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.camera.CameraViewModel
import com.example.camera.CaptureMode
import com.example.camera.ColorFilterHelper
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraScreen(
    viewModel: CameraViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    var takePhotoAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var toggleRecordAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionsList = remember {
        mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        }
    }

    val permissionsState = rememberMultiplePermissionsState(permissionsList)

    LaunchedEffect(Unit) {
        if (!permissionsState.allPermissionsGranted) {
            permissionsState.launchMultiplePermissionRequest()
        }
    }

    if (!permissionsState.allPermissionsGranted) {
        PermissionScreen(
            onRequestPermissions = { permissionsState.launchMultiplePermissionRequest() }
        )
        return
    }

    // Calculate real-time color matrix for live preview overlay
    val colorMatrix = remember(
        uiState.filterPreset,
        uiState.brightness,
        uiState.contrast,
        uiState.saturation
    ) {
        ColorFilterHelper.buildColorMatrix(
            preset = uiState.filterPreset,
            brightness = uiState.brightness,
            contrast = uiState.contrast,
            saturation = uiState.saturation
        )
    }

    // Show toast for status messages
    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearStatusMessage()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Full screen Live Camera Preview
        CameraPreviewView(
            viewModel = viewModel,
            uiState = uiState,
            colorMatrix = colorMatrix,
            onBindCameraControls = { onTakePhoto, onToggleRecord ->
                takePhotoAction = onTakePhoto
                toggleRecordAction = onToggleRecord
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top Status Bar (Mic info, Flash toggle, Lens switch)
        CameraTopBar(
            uiState = uiState,
            onFlashToggle = { viewModel.cycleFlashMode() },
            onCameraFlip = { viewModel.toggleCameraLens() },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // Collapsible Controls Drawer (Zoom, Exposure, Color Sliders, Filters)
        AnimatedVisibility(
            visible = uiState.showControlsDrawer,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            CameraControlsDrawer(
                viewModel = viewModel,
                uiState = uiState,
                modifier = Modifier.padding(bottom = 150.dp)
            )
        }

        // Bottom Action Bar (Shutter button, Mode switch, Gallery thumbnail, Drawer toggle)
        CameraBottomBar(
            uiState = uiState,
            onShutterClick = {
                if (uiState.captureMode == CaptureMode.PHOTO) {
                    takePhotoAction?.invoke()
                } else {
                    toggleRecordAction?.invoke()
                }
            },
            onModeChanged = { mode -> viewModel.setCaptureMode(mode) },
            onToggleControlsDrawer = { viewModel.toggleControlsDrawer() },
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

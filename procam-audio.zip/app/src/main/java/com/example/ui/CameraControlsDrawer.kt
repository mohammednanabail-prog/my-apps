package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.camera.CameraUiState
import com.example.camera.CameraViewModel
import com.example.camera.ControlTab
import com.example.camera.FilterPreset
import java.util.Locale

@Composable
fun CameraControlsDrawer(
    viewModel: CameraViewModel,
    uiState: CameraUiState,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Black.copy(alpha = 0.82f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Drag handle line
            Box(
                modifier = Modifier
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.4f))
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Control Tabs Header (Zoom, Exposure, Colors, Filters)
            TabRow(
                selectedTabIndex = uiState.activeControlTab.ordinal,
                containerColor = Color.Transparent,
                contentColor = Color.White,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[uiState.activeControlTab.ordinal]),
                        color = Color(0xFFFFD600)
                    )
                }
            ) {
                ControlTab.entries.forEach { tab ->
                    Tab(
                        selected = uiState.activeControlTab == tab,
                        onClick = { viewModel.setActiveControlTab(tab) },
                        text = {
                            Text(
                                text = tab.titleAr,
                                fontSize = 13.sp,
                                fontWeight = if (uiState.activeControlTab == tab) FontWeight.Bold else FontWeight.Normal,
                                color = if (uiState.activeControlTab == tab) Color(0xFFFFD600) else Color.White.copy(alpha = 0.7f)
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Content
            when (uiState.activeControlTab) {
                ControlTab.ZOOM -> {
                    ZoomControlContent(
                        zoom = uiState.zoomRatio,
                        maxZoom = uiState.maxZoomRatio,
                        onZoomChange = { viewModel.setZoomRatio(it) }
                    )
                }
                ControlTab.EXPOSURE -> {
                    ExposureControlContent(
                        exposureIndex = uiState.exposureIndex,
                        onExposureChange = { viewModel.setExposureIndex(it) }
                    )
                }
                ControlTab.COLOR -> {
                    ColorControlContent(
                        brightness = uiState.brightness,
                        contrast = uiState.contrast,
                        saturation = uiState.saturation,
                        onBrightnessChange = { viewModel.setBrightness(it) },
                        onContrastChange = { viewModel.setContrast(it) },
                        onSaturationChange = { viewModel.setSaturation(it) },
                        onReset = { viewModel.resetColorSettings() }
                    )
                }
                ControlTab.FILTERS -> {
                    FiltersControlContent(
                        selectedFilter = uiState.filterPreset,
                        onFilterSelected = { viewModel.setFilterPreset(it) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomControlContent(
    zoom: Float,
    maxZoom: Float,
    onZoomChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("مستوى التقريب (Zoom):", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(
                text = String.format(Locale.US, "%.1fx", zoom),
                color = Color(0xFFFFD600),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Slider(
            value = zoom,
            onValueChange = onZoomChange,
            valueRange = 1.0f..maxZoom.coerceAtLeast(1.1f),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFD600),
                activeTrackColor = Color(0xFFFFD600),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf(1.0f, 2.0f, 3.0f, 5.0f).forEach { targetZoom ->
                if (targetZoom <= maxZoom) {
                    val isSelected = (zoom - targetZoom).let { Math.abs(it) < 0.2f }
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isSelected) Color(0xFFFFD600) else Color.White.copy(alpha = 0.15f))
                            .clickable { onZoomChange(targetZoom) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${targetZoom.toInt()}x",
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ExposureControlContent(
    exposureIndex: Int,
    onExposureChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("التحكم بالتعريض (EV):", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
            Text(
                text = if (exposureIndex > 0) "+$exposureIndex EV" else "$exposureIndex EV",
                color = Color(0xFFFFD600),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Slider(
            value = exposureIndex.toFloat(),
            onValueChange = { onExposureChange(it.toInt()) },
            valueRange = -2.0f..2.0f,
            steps = 3,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFD600),
                activeTrackColor = Color(0xFFFFD600),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )
    }
}

@Composable
private fun ColorControlContent(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    onBrightnessChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Brightness Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("السطوع (Brightness)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            Text(String.format(Locale.US, "%.2f", brightness), color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = brightness,
            onValueChange = onBrightnessChange,
            valueRange = -0.5f..0.5f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFD600),
                activeTrackColor = Color(0xFFFFD600),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )

        // Contrast Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("التباين (Contrast)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            Text(String.format(Locale.US, "%.2f", contrast), color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = contrast,
            onValueChange = onContrastChange,
            valueRange = 0.5f..1.8f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFD600),
                activeTrackColor = Color(0xFFFFD600),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )

        // Saturation Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("التشبع بالألوان (Saturation)", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
            Text(String.format(Locale.US, "%.2f", saturation), color = Color(0xFFFFD600), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = saturation,
            onValueChange = onSaturationChange,
            valueRange = 0.0f..2.0f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFD600),
                activeTrackColor = Color(0xFFFFD600),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )

        // Reset Button
        OutlinedButton(
            onClick = onReset,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("إعادة ضبط الألوان", fontSize = 12.sp)
        }
    }
}

@Composable
private fun FiltersControlContent(
    selectedFilter: FilterPreset,
    onFilterSelected: (FilterPreset) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        FilterPreset.entries.forEach { preset ->
            val isSelected = selectedFilter == preset
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) Color(0xFFFFD600).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f))
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) Color(0xFFFFD600) else Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onFilterSelected(preset) }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = preset.titleAr,
                    color = if (isSelected) Color(0xFFFFD600) else Color.White,
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
                Text(
                    text = preset.titleEn,
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp
                )
            }
        }
    }
}

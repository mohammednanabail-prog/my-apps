package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import android.view.ViewGroup
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.camera.CameraFlashMode
import com.example.camera.CameraUiState
import com.example.camera.CameraViewModel
import com.example.camera.CaptureMode
import com.example.camera.StorageHelper
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun CameraPreviewView(
    viewModel: CameraViewModel,
    uiState: CameraUiState,
    colorMatrix: ColorMatrix,
    onBindCameraControls: (onTakePhoto: () -> Unit, onToggleRecord: () -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    var previewView: PreviewView? by remember { mutableStateOf(null) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var videoCapture: VideoCapture<Recorder>? by remember { mutableStateOf(null) }
    var activeRecording: Recording? by remember { mutableStateOf(null) }
    var camera: Camera? by remember { mutableStateOf(null) }

    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            activeRecording?.stop()
            cameraExecutor.shutdown()
        }
    }

    // Rebind camera when lensFacing, captureMode or previewView changes
    LaunchedEffect(uiState.lensFacing, uiState.captureMode, previewView) {
        val view = previewView ?: return@LaunchedEffect

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            Log.w("CameraPreviewView", "Camera permission not granted")
            return@LaunchedEffect
        }

        val cameraProvider = try {
            cameraProviderFuture.get()
        } catch (e: Exception) {
            Log.e("CameraPreviewView", "Failed to get camera provider", e)
            return@LaunchedEffect
        }

        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(uiState.lensFacing)
            .build()

        val preview = Preview.Builder().build()
        
        val newImageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(
                when (uiState.flashMode) {
                    CameraFlashMode.ON -> ImageCapture.FLASH_MODE_ON
                    CameraFlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
                    else -> ImageCapture.FLASH_MODE_OFF
                }
            )
            .build()

        val recorder = Recorder.Builder()
            .setQualitySelector(
                QualitySelector.fromOrderedList(
                    listOf(Quality.HIGHEST, Quality.FHD, Quality.HD, Quality.SD)
                )
            )
            .build()
        val newVideoCapture = VideoCapture.withOutput(recorder)

        try {
            cameraProvider.unbindAll()

            preview.setSurfaceProvider(view.surfaceProvider)

            camera = if (uiState.captureMode == CaptureMode.PHOTO) {
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    newImageCapture
                )
            } else {
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    newVideoCapture
                )
            }

            imageCapture = newImageCapture
            videoCapture = newVideoCapture

            viewModel.activeCameraControl = camera?.cameraControl
            viewModel.activeCameraInfo = camera?.cameraInfo

            camera?.cameraControl?.enableTorch(uiState.flashMode == CameraFlashMode.TORCH)

        } catch (e: Exception) {
            Log.e("CameraPreviewView", "Binding failed", e)
        }
    }

    // Pass trigger callbacks to parent without positional argument labels
    LaunchedEffect(imageCapture, videoCapture, activeRecording) {
        onBindCameraControls(
            {
                imageCapture?.let { capture ->
                    capture.takePicture(
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(image: ImageProxy) {
                                try {
                                    val buffer = image.planes[0].buffer
                                    val bytes = ByteArray(buffer.capacity())
                                    buffer.get(bytes)
                                    val uri = StorageHelper.saveImageToGallery(context, bytes)
                                    viewModel.photoCaptured(uri)
                                } catch (e: Exception) {
                                    Log.e("CameraPreviewView", "Save photo failed: ${e.message}", e)
                                    viewModel.setStatusMessage("حدث خطأ أثناء حفظ الصورة")
                                } finally {
                                    image.close()
                                }
                            }

                            override fun onError(exception: ImageCaptureException) {
                                Log.e("CameraPreviewView", "Capture failed: ${exception.message}", exception)
                                viewModel.setStatusMessage("فشل التقاط الصورة")
                            }
                        }
                    )
                } ?: viewModel.setStatusMessage("الكاميرا غير جاهزة")
            },
            {
                if (activeRecording != null) {
                    activeRecording?.stop()
                    activeRecording = null
                } else {
                    val cap = videoCapture
                    if (cap != null) {
                        val outputOptions = StorageHelper.createVideoOutputOptions(context)
                        val pendingRecording = cap.output.prepareRecording(context, outputOptions)

                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            pendingRecording.withAudioEnabled()
                        }

                        activeRecording = pendingRecording.start(ContextCompat.getMainExecutor(context)) { recordEvent ->
                            when (recordEvent) {
                                is VideoRecordEvent.Start -> {
                                    viewModel.startRecordingTimer()
                                }
                                is VideoRecordEvent.Finalize -> {
                                    if (!recordEvent.hasError()) {
                                        val uri = recordEvent.outputResults.outputUri
                                        viewModel.stopRecordingTimer(uri)
                                    } else {
                                        Log.e("CameraPreviewView", "Video record error: ${recordEvent.error}")
                                        viewModel.stopRecordingTimer(null)
                                    }
                                    activeRecording = null
                                }
                            }
                        }
                    } else {
                        viewModel.setStatusMessage("تسجيل الفيديو غير جاهز")
                    }
                }
            }
        )
    }

    // Update Torch state when flash mode toggles
    LaunchedEffect(uiState.flashMode) {
        camera?.cameraControl?.enableTorch(uiState.flashMode == CameraFlashMode.TORCH)
        imageCapture?.flashMode = when (uiState.flashMode) {
            CameraFlashMode.ON -> ImageCapture.FLASH_MODE_ON
            CameraFlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    previewView?.let { view ->
                        val factory: MeteringPointFactory = view.meteringPointFactory
                        val point = factory.createPoint(offset.x, offset.y)
                        val action = FocusMeteringAction.Builder(point).build()
                        camera?.cameraControl?.startFocusAndMetering(action)
                        viewModel.triggerTapToFocus(offset)
                    }
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }.also { view ->
                    previewView = view
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .drawWithContent {
                    drawContent()
                    drawRect(
                        color = Color.Transparent,
                        colorFilter = ColorFilter.colorMatrix(colorMatrix)
                    )
                }
        )

        // Animated Yellow Focus Indicator on Tap
        if (uiState.showFocusAnimation && uiState.tapFocusPoint != null) {
            val focusX = uiState.tapFocusPoint.x
            val focusY = uiState.tapFocusPoint.y

            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color(0xFFFFD600),
                    radius = 36.dp.toPx(),
                    center = Offset(focusX, focusY),
                    style = Stroke(width = 2.dp.toPx())
                )
                drawCircle(
                    color = Color(0xFFFFD600),
                    radius = 4.dp.toPx(),
                    center = Offset(focusX, focusY)
                )
            }
        }
    }
}

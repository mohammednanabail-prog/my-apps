package com.example.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioDeviceCallback
import android.media.AudioManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AudioDeviceInfoState(
    val isExternalMicConnected: Boolean = false,
    val deviceName: String = "المايك المدمج للجوال 🎙️",
    val deviceTypeString: String = "Built-in Microphone",
    val connectionType: AudioConnectionType = AudioConnectionType.BUILT_IN
)

enum class AudioConnectionType {
    BUILT_IN,
    USB_MIC,
    WIRED_HEADSET,
    BLUETOOTH
}

class AudioRoutingManager(private val context: Context) {

    private val TAG = "AudioRoutingManager"
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _audioState = MutableStateFlow(AudioDeviceInfoState())
    val audioState: StateFlow<AudioDeviceInfoState> = _audioState.asStateFlow()

    private val audioDeviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            Log.d(TAG, "onAudioDevicesAdded")
            updateAudioDevices()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            Log.d(TAG, "onAudioDevicesRemoved")
            updateAudioDevices()
        }
    }

    fun startMonitoring() {
        audioManager.registerAudioDeviceCallback(audioDeviceCallback, null)
        updateAudioDevices()
        routeAudioToBestMic()
    }

    fun stopMonitoring() {
        audioManager.unregisterAudioDeviceCallback(audioDeviceCallback)
    }

    fun updateAudioDevices() {
        val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        
        var foundUsb = false
        var foundWired = false
        var foundBluetooth = false

        var usbDeviceName = ""
        var wiredDeviceName = ""
        var btDeviceName = ""

        for (device in inputDevices) {
            when (device.type) {
                AudioDeviceInfo.TYPE_USB_DEVICE,
                AudioDeviceInfo.TYPE_USB_HEADSET,
                AudioDeviceInfo.TYPE_USB_ACCESSORY -> {
                    foundUsb = true
                    val name = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && !device.productName.isNullOrBlank()) {
                        device.productName.toString()
                    } else "USB Microphone"
                    usbDeviceName = name
                }
                AudioDeviceInfo.TYPE_WIRED_HEADSET -> {
                    foundWired = true
                    wiredDeviceName = "Wired Headset Mic"
                }
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> {
                    foundBluetooth = true
                    btDeviceName = "Bluetooth Mic"
                }
            }
        }

        val newState = when {
            foundUsb -> AudioDeviceInfoState(
                isExternalMicConnected = true,
                deviceName = "مايك خارجي لاسلكي / USB 🎤 ($usbDeviceName)",
                deviceTypeString = "USB External Mic",
                connectionType = AudioConnectionType.USB_MIC
            )
            foundWired -> AudioDeviceInfoState(
                isExternalMicConnected = true,
                deviceName = "سماعة سلكية مع مايك 🎧 ($wiredDeviceName)",
                deviceTypeString = "Wired Mic",
                connectionType = AudioConnectionType.WIRED_HEADSET
            )
            foundBluetooth -> AudioDeviceInfoState(
                isExternalMicConnected = true,
                deviceName = "مايك بلوتوث 📡 ($btDeviceName)",
                deviceTypeString = "Bluetooth Mic",
                connectionType = AudioConnectionType.BLUETOOTH
            )
            else -> AudioDeviceInfoState(
                isExternalMicConnected = false,
                deviceName = "المايك المدمج للجوال 🎙️",
                deviceTypeString = "Built-in Mic",
                connectionType = AudioConnectionType.BUILT_IN
            )
        }

        _audioState.value = newState
        routeAudioToBestMic()
    }

    private fun routeAudioToBestMic() {
        try {
            audioManager.mode = AudioManager.MODE_NORMAL

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
                val preferredDevice = inputDevices.firstOrNull { device ->
                    device.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    device.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
                    device.type == AudioDeviceInfo.TYPE_USB_ACCESSORY
                } ?: inputDevices.firstOrNull { device ->
                    device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
                }

                if (preferredDevice != null) {
                    val result = audioManager.setCommunicationDevice(preferredDevice)
                    Log.d(TAG, "setCommunicationDevice USB/Wired result: $result for ${preferredDevice.productName}")
                } else {
                    audioManager.clearCommunicationDevice()
                }
            } else {
                @Suppress("DEPRECATION")
                if (_audioState.value.connectionType == AudioConnectionType.BLUETOOTH) {
                    audioManager.startBluetoothSco()
                    audioManager.isBluetoothScoOn = true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error routing audio: ${e.message}", e)
        }
    }
}

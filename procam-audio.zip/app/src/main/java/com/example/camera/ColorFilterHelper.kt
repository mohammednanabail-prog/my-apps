package com.example.camera

import androidx.compose.ui.graphics.ColorMatrix

enum class FilterPreset(val titleAr: String, val titleEn: String) {
    ORIGINAL("طبيعي", "Original"),
    WARM("دافئ", "Warm"),
    COOL("بارد", "Cool"),
    BLACK_WHITE("أبيض وأسود", "B&W"),
    VIVID("زاهي", "Vivid")
}

object ColorFilterHelper {

    fun buildColorMatrix(
        preset: FilterPreset,
        brightness: Float, // -0.5 to 0.5
        contrast: Float,   // 0.5 to 1.8
        saturation: Float  // 0.0 to 2.0
    ): ColorMatrix {
        // Base identity 4x5 values
        var baseValues = floatArrayOf(
            1f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )

        // 1. Preset Matrix
        when (preset) {
            FilterPreset.ORIGINAL -> {
                // Identity
            }
            FilterPreset.WARM -> {
                baseValues = floatArrayOf(
                    1.15f, 0f, 0f, 0f, 15f,
                    0f, 1.05f, 0f, 0f, 10f,
                    0f, 0f, 0.85f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            }
            FilterPreset.COOL -> {
                baseValues = floatArrayOf(
                    0.9f, 0f, 0f, 0f, -10f,
                    0f, 1.05f, 0f, 0f, 5f,
                    0f, 0f, 1.25f, 0f, 20f,
                    0f, 0f, 0f, 1f, 0f
                )
            }
            FilterPreset.BLACK_WHITE -> {
                val r = 0.299f
                val g = 0.587f
                val b = 0.114f
                baseValues = floatArrayOf(
                    r, g, b, 0f, 0f,
                    r, g, b, 0f, 0f,
                    r, g, b, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            }
            FilterPreset.VIVID -> {
                val invSat = 1.4f
                val r = 0.213f * (1 - invSat)
                val g = 0.715f * (1 - invSat)
                val b = 0.072f * (1 - invSat)
                baseValues = floatArrayOf(
                    r + invSat, g, b, 0f, 0f,
                    r, g + invSat, b, 0f, 0f,
                    r, g, b + invSat, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            }
        }

        // 2. Custom Saturation if adjusted
        if (saturation != 1.0f && preset != FilterPreset.BLACK_WHITE) {
            val invSat = saturation
            val r = 0.213f * (1 - invSat)
            val g = 0.715f * (1 - invSat)
            val b = 0.072f * (1 - invSat)
            val satValues = floatArrayOf(
                r + invSat, g, b, 0f, 0f,
                r, g + invSat, b, 0f, 0f,
                r, g, b + invSat, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
            baseValues = multiplyMatrices(baseValues, satValues)
        }

        // 3. Contrast & Brightness
        val c = contrast
        val bOffset = brightness * 255f
        val t = (1.0f - c) * 128f + bOffset

        val contrastValues = floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )

        val finalValues = multiplyMatrices(baseValues, contrastValues)
        return ColorMatrix(finalValues)
    }

    private fun multiplyMatrices(a: FloatArray, b: FloatArray): FloatArray {
        val result = FloatArray(20)
        for (row in 0 until 4) {
            for (col in 0 until 4) {
                var sum = 0f
                for (k in 0 until 4) {
                    sum += a[row * 5 + k] * b[k * 5 + col]
                }
                result[row * 5 + col] = sum
            }
            var trans = a[row * 5 + 4]
            for (k in 0 until 4) {
                trans += a[row * 5 + k] * b[k * 5 + 4]
            }
            result[row * 5 + 4] = trans
        }
        return result
    }
}

package com.example.camera

import android.net.Uri
import androidx.camera.core.CameraSelector
import androidx.compose.ui.geometry.Offset
import com.example.audio.AudioDeviceInfoState

enum class CaptureMode(val titleAr: String, val titleEn: String) {
    PHOTO("صورة", "Photo"),
    VIDEO("فيديو", "Video")
}

enum class CameraFlashMode(val titleAr: String, val iconName: String) {
    OFF("إيقاف", "Off"),
    ON("تشغيل", "On"),
    AUTO("تلقائي", "Auto"),
    TORCH("كشاف", "Torch")
}

enum class ControlTab(val titleAr: String, val titleEn: String) {
    ZOOM("تقريب", "Zoom"),
    EXPOSURE("التعريض", "Exposure"),
    COLOR("الألوان", "Colors"),
    FILTERS("الفلاتر", "Filters")
}

data class CameraUiState(
    val captureMode: CaptureMode = CaptureMode.VIDEO,
    val lensFacing: Int = CameraSelector.LENS_FACING_BACK,
    val flashMode: CameraFlashMode = CameraFlashMode.OFF,
    val isRecording: Boolean = false,
    val recordingDurationSeconds: Long = 0L,
    val recordingTimerFormatted: String = "00:00",
    val zoomRatio: Float = 1.0f,
    val maxZoomRatio: Float = 5.0f,
    val exposureIndex: Int = 0,
    val exposureMinIndex: Int = -2,
    val exposureMaxIndex: Int = 2,
    val filterPreset: FilterPreset = FilterPreset.ORIGINAL,
    val brightness: Float = 0.0f, // -1f to 1f
    val contrast: Float = 1.0f,   // 0.5f to 2.0f
    val saturation: Float = 1.0f, // 0f to 2f
    val tapFocusPoint: Offset? = null,
    val showFocusAnimation: Boolean = false,
    val showControlsDrawer: Boolean = false,
    val activeControlTab: ControlTab = ControlTab.ZOOM,
    val audioState: AudioDeviceInfoState = AudioDeviceInfoState(),
    val lastCapturedUri: Uri? = null,
    val statusMessage: String? = null
)

package com.example.camera

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioRoutingManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "CameraViewModel"
    private val audioRoutingManager = AudioRoutingManager(application)

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    var activeCameraControl: CameraControl? = null
    var activeCameraInfo: CameraInfo? = null

    init {
        audioRoutingManager.startMonitoring()
        viewModelScope.launch {
            audioRoutingManager.audioState.collect { audioState ->
                _uiState.update { it.copy(audioState = audioState) }
            }
        }
        loadLatestThumbnail()
    }

    override fun onCleared() {
        super.onCleared()
        audioRoutingManager.stopMonitoring()
        timerJob?.cancel()
    }

    fun loadLatestThumbnail() {
        viewModelScope.launch {
            val thumbUri = StorageHelper.getLatestMediaThumbnail(getApplication())
            _uiState.update { it.copy(lastCapturedUri = thumbUri) }
        }
    }

    fun setCaptureMode(mode: CaptureMode) {
        if (_uiState.value.isRecording) return
        _uiState.update { it.copy(captureMode = mode) }
    }

    fun toggleCameraLens() {
        if (_uiState.value.isRecording) return
        val nextLens = if (_uiState.value.lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        _uiState.update { it.copy(lensFacing = nextLens) }
    }

    fun cycleFlashMode() {
        val nextFlash = when (_uiState.value.flashMode) {
            CameraFlashMode.OFF -> CameraFlashMode.ON
            CameraFlashMode.ON -> CameraFlashMode.AUTO
            CameraFlashMode.AUTO -> CameraFlashMode.TORCH
            CameraFlashMode.TORCH -> CameraFlashMode.OFF
        }
        _uiState.update { it.copy(flashMode = nextFlash) }
    }

    fun toggleControlsDrawer() {
        _uiState.update { it.copy(showControlsDrawer = !it.showControlsDrawer) }
    }

    fun setActiveControlTab(tab: ControlTab) {
        _uiState.update { it.copy(activeControlTab = tab) }
    }

    fun setZoomRatio(zoom: Float) {
        _uiState.update { it.copy(zoomRatio = zoom) }
        activeCameraControl?.setLinearZoom((zoom - 1f) / (_uiState.value.maxZoomRatio - 1f).coerceAtLeast(1f))
    }

    fun setExposureIndex(index: Int) {
        _uiState.update { it.copy(exposureIndex = index) }
        activeCameraControl?.setExposureCompensationIndex(index)
    }

    fun setFilterPreset(preset: FilterPreset) {
        _uiState.update { it.copy(filterPreset = preset) }
    }

    fun setBrightness(brightness: Float) {
        _uiState.update { it.copy(brightness = brightness) }
    }

    fun setContrast(contrast: Float) {
        _uiState.update { it.copy(contrast = contrast) }
    }

    fun setSaturation(saturation: Float) {
        _uiState.update { it.copy(saturation = saturation) }
    }

    fun resetColorSettings() {
        _uiState.update {
            it.copy(
                filterPreset = FilterPreset.ORIGINAL,
                brightness = 0.0f,
                contrast = 1.0f,
                saturation = 1.0f
            )
        }
    }

    fun triggerTapToFocus(point: Offset) {
        _uiState.update {
            it.copy(
                tapFocusPoint = point,
                showFocusAnimation = true
            )
        }
        viewModelScope.launch {
            delay(1500)
            _uiState.update { it.copy(showFocusAnimation = false) }
        }
    }

    fun startRecordingTimer() {
        _uiState.update {
            it.copy(
                isRecording = true,
                recordingDurationSeconds = 0L,
                recordingTimerFormatted = "00:00"
            )
        }
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var seconds = 0L
            while (true) {
                delay(1000)
                seconds++
                val mins = seconds / 60
                val secs = seconds % 60
                val formatted = String.format(Locale.US, "%02d:%02d", mins, secs)
                _uiState.update {
                    it.copy(
                        recordingDurationSeconds = seconds,
                        recordingTimerFormatted = formatted
                    )
                }
            }
        }
    }

    fun stopRecordingTimer(savedUri: Uri?) {
        timerJob?.cancel()
        timerJob = null
        _uiState.update {
            it.copy(
                isRecording = false,
                recordingDurationSeconds = 0L,
                recordingTimerFormatted = "00:00",
                lastCapturedUri = savedUri ?: it.lastCapturedUri,
                statusMessage = if (savedUri != null) "تم حفظ الفيديو بنجاح في معرض الصور 🎥" else "تم إيقاف التسجيل"
            )
        }
    }

    fun photoCaptured(uri: Uri?) {
        _uiState.update {
            it.copy(
                lastCapturedUri = uri ?: it.lastCapturedUri,
                statusMessage = if (uri != null) "تم التقاط الصورة وحفظها في المعرض 📸" else "تم التقط الصورة"
            )
        }
    }

    fun setStatusMessage(msg: String) {
        _uiState.update { it.copy(statusMessage = msg) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }
}

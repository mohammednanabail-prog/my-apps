package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TrashEntity
import com.example.data.model.Album
import com.example.data.model.MediaDateGroup
import com.example.data.model.MediaDetails
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class GalleryTab {
    PHOTOS,
    ALBUMS,
    FAVORITES,
    TRASH
}

enum class MediaFilterType {
    ALL,
    PHOTOS,
    VIDEOS
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

data class GalleryUiState(
    val isLoading: Boolean = true,
    val currentTab: GalleryTab = GalleryTab.PHOTOS,
    val selectedAlbum: Album? = null,
    val searchQuery: String = "",
    val mediaFilter: MediaFilterType = MediaFilterType.ALL,
    val rawMediaList: List<MediaItem> = emptyList(),
    val favoriteIds: Set<Long> = emptySet(),
    val trashIds: Set<Long> = emptySet(),
    val trashEntities: List<TrashEntity> = emptyList(),
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val selectedMediaDetails: MediaDetails? = null,
    val isDetailsDialogOpen: Boolean = false,
    val userMessage: String? = null
) {
    // Media items visible in main gallery (excluding trashed items)
    val activeMediaList: List<MediaItem>
        get() {
            var list = rawMediaList.filterNot { it.id in trashIds }

            if (selectedAlbum != null) {
                list = list.filter { it.bucketName == selectedAlbum.name || it.bucketId == selectedAlbum.id }
            }

            if (mediaFilter == MediaFilterType.PHOTOS) {
                list = list.filter { it.mediaType == MediaType.IMAGE }
            } else if (mediaFilter == MediaFilterType.VIDEOS) {
                list = list.filter { it.mediaType == MediaType.VIDEO }
            }

            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim().lowercase()
                list = list.filter {
                    it.name.lowercase().contains(q) ||
                    it.bucketName.lowercase().contains(q) ||
                    (it.mediaType == MediaType.VIDEO && (q == "video" || q == "فيديو" || q == "فيديوهات")) ||
                    (it.mediaType == MediaType.IMAGE && (q == "photo" || q == "صورة" || q == "صور"))
                }
            }

            return list.map { it.copy(isFavorite = it.id in favoriteIds) }
        }

    // Favorite items
    val favoriteMediaList: List<MediaItem>
        get() {
            return rawMediaList
                .filter { it.id in favoriteIds && it.id !in trashIds }
                .map { it.copy(isFavorite = true) }
        }
}

class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    val repository = MediaRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(GalleryUiState())
    val uiState: StateFlow<GalleryUiState> = _uiState.asStateFlow()

    init {
        // Collect favorites and trash IDs from Room
        viewModelScope.launch {
            repository.favoriteIds.collect { favs ->
                _uiState.update { it.copy(favoriteIds = favs.toSet()) }
            }
        }

        viewModelScope.launch {
            repository.trashIds.collect { trashed ->
                _uiState.update { it.copy(trashIds = trashed.toSet()) }
            }
        }

        viewModelScope.launch {
            repository.trashEntities.collect { entities ->
                _uiState.update { it.copy(trashEntities = entities) }
            }
        }

        loadMedia()
    }

    fun loadMedia() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val media = repository.loadAllMedia()
            
            // If device has 0 media, generate demo photos for seamless instant exploration!
            if (media.isEmpty()) {
                repository.generateDemoMediaIfEmpty()
                val refreshed = repository.loadAllMedia()
                _uiState.update { it.copy(rawMediaList = refreshed, isLoading = false) }
            } else {
                _uiState.update { it.copy(rawMediaList = media, isLoading = false) }
            }
        }
    }

    fun setTab(tab: GalleryTab) {
        _uiState.update { it.copy(currentTab = tab, selectedAlbum = null) }
    }

    fun selectAlbum(album: Album?) {
        _uiState.update { it.copy(selectedAlbum = album) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setMediaFilter(filter: MediaFilterType) {
        _uiState.update { it.copy(mediaFilter = filter) }
    }

    fun setThemeMode(mode: ThemeMode) {
        _uiState.update { it.copy(themeMode = mode) }
    }

    fun toggleFavorite(item: MediaItem) {
        viewModelScope.launch {
            val isFav = item.id in _uiState.value.favoriteIds
            repository.toggleFavorite(item, isFav)
        }
    }

    fun moveToTrash(item: MediaItem) {
        viewModelScope.launch {
            repository.moveToTrash(item)
            showMessage("تم نقل العنصر إلى سلة المحذوفات")
        }
    }

    fun restoreFromTrash(mediaId: Long) {
        viewModelScope.launch {
            repository.restoreFromTrash(mediaId)
            showMessage("تمت استعادة العنصر")
        }
    }

    fun deletePermanently(mediaId: Long) {
        viewModelScope.launch {
            repository.deletePermanently(mediaId)
            showMessage("تم الحذف نهائياً")
        }
    }

    fun clearAllTrash() {
        viewModelScope.launch {
            repository.clearTrash()
            showMessage("تم إفراغ سلة المحذوفات")
        }
    }

    fun openDetails(item: MediaItem) {
        viewModelScope.launch {
            val details = repository.getMediaDetails(item, isArabicLocale = true)
            _uiState.update { it.copy(selectedMediaDetails = details, isDetailsDialogOpen = true) }
        }
    }

    fun closeDetails() {
        _uiState.update { it.copy(isDetailsDialogOpen = false, selectedMediaDetails = null) }
    }

    fun shareMedia(item: MediaItem) {
        repository.shareMedia(item)
    }

    fun generateDemoMedia() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.generateDemoMediaIfEmpty()
            val media = repository.loadAllMedia()
            _uiState.update { it.copy(rawMediaList = media, isLoading = false) }
            showMessage("تمت إضافة وسائط تجريبية للمعرض بنجاح")
        }
    }

    fun showMessage(msg: String) {
        _uiState.update { it.copy(userMessage = msg) }
    }

    fun clearMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }
}

package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.local.TrashEntity
import com.example.data.model.Album
import com.example.data.model.MediaItem
import com.example.data.model.MediaType
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MediaDateGrid
import com.example.ui.components.MediaDetailsDialog
import com.example.ui.components.MediaThumbnailItem
import com.example.ui.viewmodel.GalleryTab
import com.example.ui.viewmodel.GalleryViewModel
import com.example.ui.viewmodel.MediaFilterType
import com.example.ui.viewmodel.ThemeMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryHomeScreen(
    viewModel: GalleryViewModel,
    onOpenMedia: (item: MediaItem, list: List<MediaItem>) -> Unit,
    onOpenSearch: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var showMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (uiState.selectedAlbum != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { viewModel.selectAlbum(null) }) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "رجوع للألبومات"
                                    )
                                }
                                Text(
                                    text = uiState.selectedAlbum!!.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        } else {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = onOpenSearch, modifier = Modifier.testTag("search_button")) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = stringResource(R.string.search))
                        }
                        IconButton(onClick = { showMenu = true }, modifier = Modifier.testTag("menu_button")) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "خيارات")
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("توليد صور تجريبية للاختبار") },
                                onClick = {
                                    showMenu = false
                                    viewModel.generateDemoMedia()
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        when (uiState.themeMode) {
                                            ThemeMode.SYSTEM -> "المظهر: تلقائي (النظام)"
                                            ThemeMode.LIGHT -> "المظهر: فاتح"
                                            ThemeMode.DARK -> "المظهر: داكن"
                                        }
                                    )
                                },
                                onClick = {
                                    showMenu = false
                                    val next = when (uiState.themeMode) {
                                        ThemeMode.SYSTEM -> ThemeMode.DARK
                                        ThemeMode.DARK -> ThemeMode.LIGHT
                                        ThemeMode.LIGHT -> ThemeMode.SYSTEM
                                    }
                                    viewModel.setThemeMode(next)
                                }
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
                androidx.compose.material3.HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    thickness = 1.dp
                )
            }
        },
        bottomBar = {
            Column {
                androidx.compose.material3.HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    thickness = 1.dp
                )
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    tonalElevation = 0.dp
                ) {
                    val navItemColors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )

                    NavigationBarItem(
                        selected = uiState.currentTab == GalleryTab.PHOTOS && uiState.selectedAlbum == null,
                        onClick = { viewModel.setTab(GalleryTab.PHOTOS) },
                        icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = stringResource(R.string.photos_tab)) },
                        label = { Text(stringResource(R.string.photos_tab), fontWeight = if (uiState.currentTab == GalleryTab.PHOTOS && uiState.selectedAlbum == null) FontWeight.Bold else FontWeight.Medium) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("tab_photos")
                    )
                    NavigationBarItem(
                        selected = uiState.currentTab == GalleryTab.ALBUMS || uiState.selectedAlbum != null,
                        onClick = { viewModel.setTab(GalleryTab.ALBUMS) },
                        icon = { Icon(Icons.Default.Folder, contentDescription = stringResource(R.string.albums_tab)) },
                        label = { Text(stringResource(R.string.albums_tab), fontWeight = if (uiState.currentTab == GalleryTab.ALBUMS || uiState.selectedAlbum != null) FontWeight.Bold else FontWeight.Medium) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("tab_albums")
                    )
                    NavigationBarItem(
                        selected = uiState.currentTab == GalleryTab.FAVORITES,
                        onClick = { viewModel.setTab(GalleryTab.FAVORITES) },
                        icon = { Icon(Icons.Default.Star, contentDescription = stringResource(R.string.favorites_tab)) },
                        label = { Text(stringResource(R.string.favorites_tab), fontWeight = if (uiState.currentTab == GalleryTab.FAVORITES) FontWeight.Bold else FontWeight.Medium) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("tab_favorites")
                    )
                    NavigationBarItem(
                        selected = uiState.currentTab == GalleryTab.TRASH,
                        onClick = { viewModel.setTab(GalleryTab.TRASH) },
                        icon = { Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.trash_tab)) },
                        label = { Text(stringResource(R.string.trash_tab), fontWeight = if (uiState.currentTab == GalleryTab.TRASH) FontWeight.Bold else FontWeight.Medium) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("tab_trash")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (uiState.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                when (uiState.currentTab) {
                    GalleryTab.PHOTOS -> {
                        PhotosTabContent(
                            viewModel = viewModel,
                            uiState = uiState,
                            onOpenMedia = onOpenMedia
                        )
                    }
                    GalleryTab.ALBUMS -> {
                        if (uiState.selectedAlbum != null) {
                            // Showing specific album items
                            val albumItems = uiState.activeMediaList
                            val grouped = viewModel.repository.groupMediaByDate(albumItems)
                            if (albumItems.isEmpty()) {
                                EmptyStateView(
                                    icon = Icons.Default.Folder,
                                    title = "الألبوم فارغ",
                                    description = "لا توجد صور في هذا الألبوم"
                                )
                            } else {
                                MediaDateGrid(
                                    groupedMedia = grouped,
                                    onItemClick = { item -> onOpenMedia(item, albumItems) }
                                )
                            }
                        } else {
                            AlbumsTabContent(
                                viewModel = viewModel,
                                uiState = uiState
                            )
                        }
                    }
                    GalleryTab.FAVORITES -> {
                        FavoritesTabContent(
                            viewModel = viewModel,
                            uiState = uiState,
                            onOpenMedia = onOpenMedia
                        )
                    }
                    GalleryTab.TRASH -> {
                        TrashTabContent(
                            viewModel = viewModel,
                            uiState = uiState
                        )
                    }
                }
            }
        }
    }

    // Media Details Dialog
    if (uiState.isDetailsDialogOpen && uiState.selectedMediaDetails != null) {
        MediaDetailsDialog(
            details = uiState.selectedMediaDetails!!,
            onDismiss = { viewModel.closeDetails() }
        )
    }
}

@Composable
private fun PhotosTabContent(
    viewModel: GalleryViewModel,
    uiState: com.example.ui.viewmodel.GalleryUiState,
    onOpenMedia: (item: MediaItem, list: List<MediaItem>) -> Unit
) {
    val items = uiState.activeMediaList
    val grouped = viewModel.repository.groupMediaByDate(items)

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chipColors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                containerColor = MaterialTheme.colorScheme.surface,
                labelColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val chipBorder = FilterChipDefaults.filterChipBorder(
                enabled = true,
                selected = false,
                borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            )

            FilterChip(
                selected = uiState.mediaFilter == MediaFilterType.ALL,
                onClick = { viewModel.setMediaFilter(MediaFilterType.ALL) },
                label = { Text(stringResource(R.string.all_media), fontWeight = if (uiState.mediaFilter == MediaFilterType.ALL) FontWeight.SemiBold else FontWeight.Normal) },
                shape = RoundedCornerShape(8.dp),
                colors = chipColors,
                border = chipBorder
            )
            FilterChip(
                selected = uiState.mediaFilter == MediaFilterType.PHOTOS,
                onClick = { viewModel.setMediaFilter(MediaFilterType.PHOTOS) },
                label = { Text(stringResource(R.string.photos_only), fontWeight = if (uiState.mediaFilter == MediaFilterType.PHOTOS) FontWeight.SemiBold else FontWeight.Normal) },
                shape = RoundedCornerShape(8.dp),
                colors = chipColors,
                border = chipBorder
            )
            FilterChip(
                selected = uiState.mediaFilter == MediaFilterType.VIDEOS,
                onClick = { viewModel.setMediaFilter(MediaFilterType.VIDEOS) },
                label = { Text(stringResource(R.string.videos_only), fontWeight = if (uiState.mediaFilter == MediaFilterType.VIDEOS) FontWeight.SemiBold else FontWeight.Normal) },
                shape = RoundedCornerShape(8.dp),
                colors = chipColors,
                border = chipBorder
            )
        }

        if (items.isEmpty()) {
            EmptyStateView(
                icon = Icons.Outlined.PhotoLibrary,
                title = stringResource(R.string.empty_gallery_title),
                description = stringResource(R.string.empty_gallery_desc),
                actionButtonText = stringResource(R.string.generate_demo_media),
                onActionClick = { viewModel.generateDemoMedia() }
            )
        } else {
            MediaDateGrid(
                groupedMedia = grouped,
                onItemClick = { item -> onOpenMedia(item, items) }
            )
        }
    }
}

@Composable
private fun AlbumsTabContent(
    viewModel: GalleryViewModel,
    uiState: com.example.ui.viewmodel.GalleryUiState
) {
    val albums = viewModel.repository.extractAlbums(uiState.rawMediaList.filterNot { it.id in uiState.trashIds })

    if (albums.isEmpty()) {
        EmptyStateView(
            icon = Icons.Default.Folder,
            title = "لا توجد ألبومات",
            description = "سيتم تجميع ألبومات الصور تلقائياً هنا."
        )
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(albums, key = { it.id }) { album ->
                AlbumCard(
                    album = album,
                    onClick = { viewModel.selectAlbum(album) }
                )
            }
        }
    }
}

@Composable
fun AlbumCard(
    album: Album,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag("album_${album.name}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (album.coverUri != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(album.coverUri)
                            .crossfade(true)
                            .build(),
                        contentDescription = album.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        modifier = Modifier
                            .size(48.dp)
                            .align(Alignment.Center),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = album.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stringResource(R.string.items_count, album.count),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FavoritesTabContent(
    viewModel: GalleryViewModel,
    uiState: com.example.ui.viewmodel.GalleryUiState,
    onOpenMedia: (item: MediaItem, list: List<MediaItem>) -> Unit
) {
    val items = uiState.favoriteMediaList
    val grouped = viewModel.repository.groupMediaByDate(items)

    if (items.isEmpty()) {
        EmptyStateView(
            icon = Icons.Outlined.StarBorder,
            title = stringResource(R.string.empty_favorites_title),
            description = stringResource(R.string.empty_favorites_desc)
        )
    } else {
        MediaDateGrid(
            groupedMedia = grouped,
            onItemClick = { item -> onOpenMedia(item, items) }
        )
    }
}

@Composable
private fun TrashTabContent(
    viewModel: GalleryViewModel,
    uiState: com.example.ui.viewmodel.GalleryUiState
) {
    var showEmptyConfirmDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        if (uiState.trashEntities.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${uiState.trashEntities.size} عنصر في السلة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { showEmptyConfirmDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.empty_trash_button), fontSize = 12.sp)
                }
            }
        }

        if (uiState.trashEntities.isEmpty()) {
            EmptyStateView(
                icon = Icons.Outlined.Delete,
                title = stringResource(R.string.empty_trash_title),
                description = stringResource(R.string.empty_trash_desc)
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(uiState.trashEntities, key = { it.mediaId }) { item ->
                    TrashItemRow(
                        item = item,
                        onRestore = { viewModel.restoreFromTrash(item.mediaId) },
                        onPermanentDelete = { viewModel.deletePermanently(item.mediaId) }
                    )
                }
            }
        }
    }

    if (showEmptyConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showEmptyConfirmDialog = false },
            title = { Text(stringResource(R.string.confirm_empty_trash_title)) },
            text = { Text(stringResource(R.string.confirm_empty_trash_desc)) },
            confirmButton = {
                Button(
                    onClick = {
                        showEmptyConfirmDialog = false
                        viewModel.clearAllTrash()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(stringResource(R.string.confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEmptyConfirmDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
fun TrashItemRow(
    item: TrashEntity,
    onRestore: () -> Unit,
    onPermanentDelete: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy", Locale("ar")).format(Date(item.deletedAt))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = item.uriString,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "حُذف في: $dateStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            IconButton(onClick = onRestore) {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = stringResource(R.string.restore),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            IconButton(onClick = onPermanentDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = stringResource(R.string.delete_permanently),
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: GalleryViewModel,
    onBack: () -> Unit,
    onOpenMedia: (item: MediaItem, list: List<MediaItem>) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    var searchText by remember { mutableStateOf(uiState.searchQuery) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = {
                                searchText = it
                                viewModel.setSearchQuery(it)
                            },
                            placeholder = { Text(stringResource(R.string.search_hint), fontSize = 14.sp) },
                            trailingIcon = {
                                if (searchText.isNotEmpty()) {
                                    IconButton(onClick = {
                                        searchText = ""
                                        viewModel.setSearchQuery("")
                                    }) {
                                        Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 8.dp)
                                .testTag("search_text_field"),
                            shape = RoundedCornerShape(8.dp)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.setSearchQuery("")
                            onBack()
                        }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
                androidx.compose.material3.HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    thickness = 1.dp
                )
            }
        }
    ) { paddingValues ->
        val results = uiState.activeMediaList
        val grouped = viewModel.repository.groupMediaByDate(results)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (results.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Search,
                    title = "لا توجد نتائج",
                    description = "جرب البحث باسم صورة، ألبوم، أو صيغة أخرى."
                )
            } else {
                MediaDateGrid(
                    groupedMedia = grouped,
                    onItemClick = { item -> onOpenMedia(item, results) }
                )
            }
        }
    }
}
